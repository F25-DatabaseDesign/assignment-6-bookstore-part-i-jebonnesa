from flask import Flask, render_template, request, redirect, url_for, make_response



app = Flask(__name__)
categories = [
    [1, "Shonen"],
    [2, "Josei"],
    [3, "Seinen"],
    [4, "Shojo"]
]

books = [
    #categoryId = 1
    [1, 1, "Naruto", "Masashi Kishimoto", "9781421502403", 9.99, "naruto.jpg", 1],
    [2, 1, "One Piece", "Eiichiro Oda", "9781421501680", 9.99, "onepiece.jpg", 0],
    [3, 1, "My Hero Academia", "Kohei Horikoshi", "9781421582696", 9.99, "mha.jpg", 1],
    [4, 1, "Jujutsu Kaisen", "Gege Akutami", "9781974710020", 9.99, "jjk.jpg", 0],

    # categoryId = 2
    [5, 2, "Nana", "Ai Yazawa", "9781421501086", 10.99, "nana.jpg", 1],
    [6, 2, "Chihayafuru", "Yuki Suetsugu", "9784063728408", 11.99, "chihayafuru.jpg", 0],
    [7, 2, "Paradise Kiss", "Ai Yazawa", "9781934496493", 12.99, "paradisekiss.jpg", 1],
    [8, 2, "Honey and Clover", "Chica Umino", "9781421501680", 10.99, "honeyandclover.jpg", 0],

    #categoryId = 3
    [9, 3, "Tokyo Ghoul", "Sui Ishida", "9781421580364", 12.99, "tokyoghoul.jpg", 1],
    [10, 3, "Vagabond", "Takehiko Inoue", "9781421520599", 13.99, "vagabond.jpg", 0],
    [11, 3, "Vinland Saga", "Makoto Yukimura", "9781612624204", 13.99, "vinlandsaga.jpg", 1],
    [12, 3, "Berserk", "Kentaro Miura", "9781593070205", 14.99, "berserk.jpg", 0],

    #categoryId = 4
    [13, 4, "Fruits Basket", "Natsuki Takaya", "9781591826033", 10.99, "fruitsbasket.jpg", 1],
    [14, 4, "Ao Haru Ride", "Io Sakisaka", "9784088468290", 9.99, "aoharuride.jpg", 0],
    [15, 4, "Ouran High School Host Club", "Bisco Hatori", "9781591169154", 9.99, "ouran.jpg", 1],
    [16, 4, "Sailor Moon", "Naoko Takeuchi", "9783499192718", 9.99, "sailormoon.jpg", 0]
]

# Create a list called categories. The elements in the list should be lists that contain the following information in this order:
#   categoryId
#   categoryName
#   An example of a single category list is: [1, "Biographies"]

# Create a list called books. The elements in the list should be lists that contain the following information in this order:
#   bookId     (you can assign the bookId - preferably a number from 1-16)
#   categoryId (this should be one of the categories in the category dictionary)
#   title
#   author
#   isbn
#   price      (the value should be a float)
#   image      (this is the filename of the book image.  If all the images, have the same extension, you can omit the extension)
#   readNow    (This should be either 1 or 0.  For each category, some of the books (but not all) should have this set to 1.
#   An example of a single category list is: [1, 1, "Madonna", "Andrew Morton", "13-9780312287863", 39.99, "madonna.png", 1]

#books = [
    # Biographies
#   [1, 1, "Beethoven", "David Jacobs", "13-9780304936588", 9.99, "beethoven.gif", 0],
#   [2, 1, "Madonna", "Andrew Morton", "13-9780312287863", 12.99, "madonna.jpg", 1],
#   [3, 1, "Clapton: The Autobiography", "Eric Clapton", "13-9780767925365", 10.99, "clapton.jpg", 1],
#   [4, 1, "Music is My Mistress", "Edward Kennedy Ellington", "13-9780303608037", 68.99, "ellington.jpg", 0],

    # Learn to Play placeholders
#   [5, 2, "Play Piano Today!", "Hal Leonard", "13-9780634069321", 19.99, "piano.jpg", 1],
#   [6, 2, "Guitar Basics", "James Longworth", "13-9780571538163", 14.99, "guitar.jpg", 0],

    # Music Theory placeholders
#   [7, 3, "Music Theory Essentials", "Jason W. Solomon", "13-9781423492724", 21.95, "theory.jpg", 1],

    # Scores and Charts placeholders
#   [8, 4, "Classical Favorites", "Various", "13-9780793512737", 15.99, "scores.jpg", 0],
#]



@app.route('/')
def home():
    return render_template("index.html", categories=categories)


@app.route('/category/<int:categoryId>')
def category(categoryId):
    # Filter books by selected category
    selected_books = [b for b in books if b[1] == categoryId]

    return render_template(
        "category.html",
        selectedCategory=categoryId,
        categories=categories,
        books=selected_books
    )


# we'll link this for project 2 to an sqlite3 database using flask's get_db() function
@app.route('/search')
def search():
    #Link to the search results page.
    return render_template()

@app.errorhandler(Exception)
def handle_error(e):
    """
    Output any errors - good for debugging.
    """
    return render_template('error.html', error=e) # render the edit template


if __name__ == "__main__":
    app.run(debug = True)
